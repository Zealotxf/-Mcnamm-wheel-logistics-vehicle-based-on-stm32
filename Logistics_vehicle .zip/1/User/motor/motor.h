#ifndef MOTOR_H
#define MOTOR_H

#include "stm32f10x.h"

void Motor_Forward(uint16_t Duty);
void Motor_Back(uint16_t Duty);
void Motor_Left_Translation(uint16_t Duty);
void Motor_Right_Translation(uint16_t Duty);
void Motor_Left(uint16_t Duty);
void Motor_Right(uint16_t Duty);
void Motor_Farfred(uint16_t Duty);
void Motor_Stop(void);
void Motor_Clockside_Rotate(void);
void Motor_Anticlockside_Rotate(void);


#endif /* MOTOR_H */
